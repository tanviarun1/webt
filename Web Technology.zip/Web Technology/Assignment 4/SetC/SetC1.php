<?php
	$n=$_GET['n'];
	$a=array();
	$a[]="Nidhi";
	$a[]="Shruti";
	$a[]="Rutuja";
	$a[]="Ashish";
	$a[]="Tanvi";
	echo "List of Names=<br>";
	foreach($a as $v)
	{
		$s=substr($v,0,strlen($n));
		if($s===$n)
		echo "$v<br>";
	}
?>
