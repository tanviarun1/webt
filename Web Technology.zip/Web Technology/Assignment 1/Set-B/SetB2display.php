<?php
$a=$_POST["+4"];
$b=$_POST["+5"];
$c=$_POST["+6"];
session_start();
echo"<br><b>Employee Details<br>";
echo"Employee Name:".$_SESSION["enm"]."<Br>";
echo"Employee Address:".$_SESSION["add"]."<Br>";
$sum=$a+$b+$c;
echo"<br>TOTAL EARNING:".$sum;
?>



